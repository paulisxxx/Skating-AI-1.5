const categorias = {
  "🌀 GIROS (SPINS)": [
    "Camel Spin",
    "Sit Spin",
    "Layback Spin",
    "Biellmann Spin",
    "Back Spin"
  ],
  "❄️ SALTOS (JUMPS)": [
    "Axel simple", "Doble Axel", "Triple Axel",
    "Loop simple", "Loop doble", "Loop triple",
    "Salchow simple", "Salchow doble", "Salchow triple",
    "Flip simple", "Flip doble", "Flip triple",
    "Lutz simple", "Lutz doble", "Lutz triple",
    "Toe Loop simple", "Toe Loop doble", "Toe Loop triple"
  ]
};

const contenedor = document.getElementById('contenedor');
const canvas = document.getElementById('poseCanvas');
const ctxCanvas = canvas.getContext('2d');
const feedbackBox = document.getElementById('feedbackBox');
const feedbackText = document.getElementById('feedbackText');
const scoreText = document.getElementById('scoreText');

for (let categoria in categorias) {
  const seccion = document.createElement('section');
  const titulo = document.createElement('h2');
  titulo.textContent = categoria;
  seccion.appendChild(titulo);

  const grid = document.createElement('div');
  grid.classList.add('cards-container');

  categorias[categoria].forEach(elemento => {
    const imgNombre = elemento.replace(/\s+/g, '_') + ".jpg";
    const card = document.createElement('div');
    card.classList.add('card');
    card.innerHTML = `
      <img src="img/${imgNombre}" alt="${elemento}" onerror="this.src='https://via.placeholder.com/220x150?text=Sin+imagen'">
      <h3>${elemento}</h3>
      <input type="file" accept="video/*" onchange="analizarVideo(this, '${elemento}')">
    `;
    grid.appendChild(card);
  });

  seccion.appendChild(grid);
  contenedor.appendChild(seccion);
}

let detector;
async function cargarModelo() {
  detector = await poseDetection.createDetector(poseDetection.SupportedModels.MoveNet);
  console.log("✅ Modelo cargado");
}
cargarModelo();

async function analizarVideo(fileInput, elemento) {
  const file = fileInput.files[0];
  if (!file) return alert("Sube un video");

  const video = document.createElement("video");
  video.src = URL.createObjectURL(file);
  video.muted = true;
  await video.play();

  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;

  let feedbacks = [];
  let scores = [];
  let frameCount = 0;

  const interval = setInterval(async () => {
    if (frameCount >= 30 || video.ended) {
      clearInterval(interval);
      mostrarFeedback(feedbacks, scores);
      return;
    }

    ctxCanvas.clearRect(0, 0, canvas.width, canvas.height);
    ctxCanvas.drawImage(video, 0, 0, canvas.width, canvas.height);

    const poses = await detector.estimatePoses(video);

    if (poses.length > 0) {
      dibujarEsqueleto(poses[0].keypoints);
      const { mensajes, score } = evaluarElemento(poses[0].keypoints, elemento);
      feedbacks.push(...mensajes);
      scores.push(score);
    }

    frameCount++;
  }, 300);
}

function dibujarEsqueleto(puntos) {
  ctxCanvas.lineWidth = 3;
  ctxCanvas.strokeStyle = "cyan";
  puntos.forEach(p => {
    if (p.score > 0.5) {
      ctxCanvas.beginPath();
      ctxCanvas.arc(p.x, p.y, 4, 0, 2 * Math.PI);
      ctxCanvas.fillStyle = "red";
      ctxCanvas.fill();
    }
  });
}

function evaluarElemento(puntos, elemento) {
  let mensajes = [];
  let score = 50;

  const hombro = puntos.find(p => p.name === "left_shoulder");
  const cadera = puntos.find(p => p.name === "left_hip");
  const rodilla = puntos.find(p => p.name === "left_knee");
  const tobillo = puntos.find(p => p.name === "left_ankle");

  if (elemento.includes("Sit Spin")) {
    if (rodilla.y > cadera.y + 50) {
      mensajes.push("✅ Buena posición baja para Sit Spin");
      score += 40;
    } else {
      mensajes.push("⚠ Baja más la cadera");
    }
  }

  if (elemento.includes("Camel Spin")) {
    if (Math.abs(hombro.y - cadera.y) < 30) {
      mensajes.push("✅ Torso paralelo al hielo");
      score += 30;
    } else {
      mensajes.push("⚠ Inclina más la espalda");
    }
  }

  if (elemento.includes("Layback")) {
    if (hombro && cadera && hombro.x < cadera.x - 20) {
      mensajes.push("✅ Buena inclinación hacia atrás");
      score += 30;
    } else {
      mensajes.push("⚠ Inclina más el torso hacia atrás");
    }
  }

  if (elemento.includes("Biellmann")) {
    if (tobillo && hombro && tobillo.y < hombro.y - 20) {
      mensajes.push("✅ Pierna elevada sobre la cabeza");
      score += 40;
    } else {
      mensajes.push("⚠ Eleva más la pierna");
    }
  }

  return { mensajes, score };
}

function mostrarFeedback(feedbacks, scores) {
  const unico = [...new Set(feedbacks)];
  const promedio = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  let nivel = "Necesita práctica";
  if (promedio >= 80) nivel = "Perfecto";
  else if (promedio >= 60) nivel = "Bueno";

  feedbackText.textContent = unico.join(" | ");
  scoreText.textContent = `Puntaje: ${promedio}/100 (${nivel})`;

  const bar = document.getElementById('scoreBar');
  bar.style.width = "0%";
  setTimeout(() => {
    bar.style.width = promedio + "%";
  }, 100);

  feedbackBox.classList.remove("hidden");
}

function cerrarFeedback() {
  feedbackBox.classList.add("hidden");
}
